package com.employee_workflow.Employee_System_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSystemBackendApplication.class, args);
	}

}
