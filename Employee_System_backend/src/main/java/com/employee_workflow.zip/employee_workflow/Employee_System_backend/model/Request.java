package com.employee_workflow.Employee_System_backend.model;

public class Request {

}
