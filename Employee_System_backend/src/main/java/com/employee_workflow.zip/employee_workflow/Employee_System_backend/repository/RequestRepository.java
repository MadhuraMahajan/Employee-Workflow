package com.employee_workflow.Employee_System_backend.repository;

public interface RequestRepository {

}
